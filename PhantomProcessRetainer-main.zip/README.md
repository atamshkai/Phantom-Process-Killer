<h1 align="center">👻 Let the Ghosts out!</h1>

<div align="center">
  <!-- Version -->
    <img src="https://img.shields.io/badge/Version-v1.0-blue.svg?longCache=true&style=popout-square"
      alt="Version" />
  <!-- Last Updated -->
    <img src="https://img.shields.io/badge/Updated-August 08, 2022-green.svg?longCache=true&style=flat-square"
      alt="_time_stamp_" />
  <!-- Min Magisk -->
    <img src="https://img.shields.io/badge/MinMagisk-20.4-red.svg?longCache=true&style=flat-square"
      alt="_time_stamp_" /></div>

<div align="center">
  <strong>
    Let the Ghosts Out (Formely known as Phantom Process Retainer) is a Magisk Module that aims to disable Phantom Process Killer, implemented on Android 12.
  </strong>
</div>

<div align="center">
  <h3>
    Why should i disable Phantom Process Killer?
  </h3>
    Phantom Process Killer may mess with apps like Termux, Tasker, Andronix, Debian NoRoot, McAfee Antivirus, etc...
</div>

<div align="center">
  <h3>
    How can i see if Phantom Process Killer was Disabled?
  </h3>
    Paste the following command on any Terminal Emulator

    su -c /system/bin/device_config get activity_manager max_phantom_processes
</div>
<p align="center">
    If the terminal displays <strong>2147483647</strong>, then it worked!
</p>

<div align="center">
  <h3>
    Installation
  </h3>
    Flash and Forget :)
</div>

### [Source](https://www.reddit.com/r/SamsungDex/comments/s6n6xt/android12_google_silently_deploys_phantom_process/)
